#include<stdio.h>

int i;

int main(void)
{
    for(i=10;i>=1;i--)
    {
        printf("%d ", i);
    }

    return 0;
}