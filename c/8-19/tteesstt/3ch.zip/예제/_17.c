#include<stdio.h>
int i;

int main(void)
{
    for(i=1;i<=10;i++)
        printf("%d ", i);

    return 0;
}