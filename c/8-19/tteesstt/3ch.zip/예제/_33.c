#include<stdio.h>

int i,j;
int num = 0;

int main(void)
{
    for(i=1;i<=100;i++)
    {
        for(j = 1; )      

    }








}